UTILISATION:

Pour utiliser notre code vous pouvez utiliser le fichier 'projet.ml' en mode interpréteur. Des tests y sont déjà insérés.
il est aussi possible de tester notre code avec un flot d'entrée. Pour cela, il faut ouvrir un terminal et exécuter le script 'flot_entree' avec ocamlrun. Ce script attendra
que vous inscriviez vos expressions. Une fois la suite de vos expressions écrites, faites 'entree' puis 'Ctrl+D'.

SPECIFICITE(S):

Pour ce projet, nous avons utilisé une liste en lieu et place d'une pile (imitant le comportement de celui-ci) pour pouvoir l'utiliser plus simplement commme valeur de cumul dans une fonction 'fold_left'.
